<?php

function build_image(ImageDTO $img): string {
    global $root;
    global $template_engine;

    $img_template =
        $template_engine->load_template("image.template.html");
    
    $img_template->insert_all(array(
        "src" => "{$root}/assets/img/{$img->path}",
        "alt" => $img->alt
    ));
    return $img_template->build();
}

function make_error(string $message): string {
    global $template_engine;
    $error_template =
        $template_engine->load_template("error.template.html");
    $error_template->insert("error", $message);
    return $error_template->build();
}

function make_success(string $message): string {
    global $template_engine;
    $error_template =
        $template_engine->load_template("success.template.html");
    $error_template->insert("success", $message);
    return $error_template->build();
}

$actions = array(
    array("index.php", "Home"),
    array("corsi.php", "Corsi"),
    array("aule.php", "Aule studio"),
    array("servizi.php", "Servizi"),
    array("faq.php", "<abbr lang=\"en\"
            title=\"Frequently Asked Question\">F.A.Q.</abbr>"),
);

function build_header(): string {
    global $template_engine;
    global $page_index;
    global $actions;

    $header_template =
        $template_engine->load_template("header.template.html");

    $actions_len = count($actions);
    foreach ($actions as $i => $action) {
        $id = "action{$i}";
        $element = "";
        if ($i === $page_index) {
            $element = make_list_item($action[1], "active");
        } else {
            $element = make_list_item(make_link($action[1], $action[0]));
        }
        $header_template->insert($id, $element);
    }

    $action = " ";
    if (isset($_SESSION["logged_user"])
        && $_SESSION["logged_user"] !== null) {
        // Area personale
        if ($actions_len + 0 === $page_index) {
            $action .= make_list_item("Profilo", "active");
        } else {
            $action .= make_list_item(make_link("Profilo", "profilo.php"));
        }
        // Esci
        if ($actions_len + 1 === $page_index) {
            $action .= make_list_item("Esci", "active");
        } else {
            $action .= make_list_item(make_link("Esci", "app/logout_engine.php"));
        }
    } else {
        // Accedi action
        if ($actions_len + 0 === $page_index) {
            $action .= make_list_item("Accedi", "active");
        } else {
            $action .= make_list_item(make_link("Accedi", "accedi.php"));
        }

        // Accedi action
        if ($actions_len + 1 === $page_index) {
            $action .= make_list_item("Registrati", "active");
        } else {
            $action .= make_list_item(make_link("Registrati", "registrati.php"));
        }
    }
    
    $header_template->insert("userlogin_action", $action);
    return $header_template->build();
}

function build_footer(): string {
    global $template_engine;

    $header_template = $template_engine->load_template("footer.template.html");
    return $header_template->build();
}

function make_list_item(string $content, ?string $class = null): string {
    $open = "<li>";
    if ($class !== null) {
        $open = "<li class=\"{$class}\">";
    }
    return "{$open}{$content}</li>";
}

function make_link(string $content, string $ref, ?string $class = null): string {
    $open = "<a";
    if ($class !== null) {
        $open .= " class=\"{$class}\"";
    }
    return "{$open} href='{$ref}'>{$content}</a>";
}

function render_stars(int $n): string {
    $ret = "";
    for ($i = 0; $i < $n; ++$i) {
        $ret .= "★";
    }
    for ($i = $n; $i < 5; ++$i) {
        $ret .= "☆";
    }
    return "<abbr title='$n stelle su 5'>$ret</abbr>";
}

function make_review(ReviewDTO $review): string {
    global $template_engine;

    $edit = "";
    if (isset($_SESSION["logged_user"])) {
        $user = $_SESSION["logged_user"];
        if ($user->username === $review->user->username) {
            $template = $template_engine->load_template("editdelete.template.html");
            $template->insert("id", $review->id);
            $template->insert("type", $review->type);
            $edit = $template->build();
        } else if ($user->role === Role::ADMIN) {
            $template = $template_engine->load_template("delete.template.html");
            $template->insert("id", $review->id);
            $template->insert("type", $review->type);
            $edit = $template->build();
        }
    }

    $template = $template_engine->load_template("recensione.template.html");
    $template->insert_all(array(
        "utente" => "{$review->user->name} {$review->user->surname}
                        (@{$review->user->username})",
        "testo"  => $review->text,
        "nstars" => $review->rating,
        "id"     => $review->id,
        "type"   => $review->type,
        "stelle" => render_stars($review->rating),
        "controls" => $edit
    ));
    return $template->build();
}

function make_user_review(ReviewDTO $review, string $location): string {
    global $template_engine;

    $template = $template_engine->load_template("recensioneprofilo.template.html");
    $template->insert_all(array(
        "elemento" => $location,
        "testo"  => $review->text,
        "nstars" => $review->rating,
        "id"     => $review->id,
        "type"   => $review->type,
        "stelle" => render_stars($review->rating)
    ));
    return $template->build();
}

function make_reviews(array $reviews): string {
    global $template_engine;
    $template = $template_engine->load_template("recensioni.template.html");
    $ret = "";
    foreach ($reviews as $review) {
        $ret .= make_review($review);
    }
    $template->insert("recensioni", $ret);
    return $template->build();
}

function make_user_reviews(array $reviews, array $locations): string {
    global $template_engine;
    $template = $template_engine->load_template("recensioni.template.html");
    $ret = "";
    $index = 0;
    foreach ($reviews as $review) {
        $ret .= make_user_review($review, $locations[$index]);
        $index++;
    }
    $template->insert("recensioni", $ret);
    return $template->build();
}

function make_review_form(int $type, int $id, string $redir): string {
    global $template_engine;

    if (isset($_SESSION["logged_user"])
        && $_SESSION["logged_user"] !== null) {
        $template = $template_engine->load_template("formrecensione.template.html");
        $template->insert_all(array(
            "id" => $id,
            "type" => $type,
        ));
        return $template->build();
    } else {
        $template = $template_engine->load_template(
            "requestlogin.template.html");
        $template->insert("redir", urlencode($redir));
        return $template->build();
    }
}


?>